export const USERS = [{
  "Metrics": "% defect leakage to BAT",
  "Jun23": "50%",
  "Jul23": "25%",
  "Aug23": "20%"
}, {
  "Metrics": "% defect leakage to Production",
  "Jun23": "70%",
  "Jul23": "35%",
  "Aug23": "10%"
}, {
  "Metrics": "Schedule variance",
  "Jun23": "80%",
  "Jul23": "35%",
  "Aug23": "20%"
}
];