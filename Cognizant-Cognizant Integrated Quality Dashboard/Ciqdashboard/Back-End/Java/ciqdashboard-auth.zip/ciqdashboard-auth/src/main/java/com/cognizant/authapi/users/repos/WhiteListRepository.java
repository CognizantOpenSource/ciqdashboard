/*
package com.cognizant.authapi.users.repos;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface WhiteListRepository extends MongoRepository<WhiteList, String> {
}
*/
